#include "pch.h"
#include "CppUnitTest.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace FeeroCS405Module5CppCheck
{
	TEST_CLASS(FeeroCS405Module5CppCheck)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
		}
	};
}
